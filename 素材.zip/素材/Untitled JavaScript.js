// Head Tilt Quiz
var questions = [
    { prompt: "第 1 題：台灣首都是台北嗎？", correct: 0 },
    { prompt: "第 2 題：2 + 2 等於 5 嗎？", correct: 1 },
    { prompt: "第 3 題：太陽從東方升起嗎？", correct: 0 }
];

var headBinding = script.getSceneObject().getComponent("Component.Head");
var quizText = findQuizText();
var questionIndex = 0;
var score = 0;
var baseRotation = null;
var lastDirection = -1;
var holdTimer = 0;
var neutralTimer = 0;
var awaitingNeutral = false;
var feedback = "";
var feedbackTimer = 0;
var finished = false;
var holdRequired = 2.0;
var tiltThreshold = 14;

function findQuizText() {
    function search(obj) {
        var textComp = obj.getComponent("Component.Text");
        if (textComp) { return textComp; }
        for (var i = 0; i < obj.getChildrenCount(); i++) {
            var found = search(obj.getChild(i));
            if (found) { return found; }
        }
        return null;
    }
    for (var i = 0; i < global.scene.getRootObjectsCount(); i++) {
        var found = search(global.scene.getRootObject(i));
        if (found) { return found; }
    }
    return null;
}

function updateDisplay() {
    if (!quizText) { return; }
    quizText.size = 36;
    if (finished) {
        quizText.text = "問答完成！\n得分：" + score + " / " + questions.length;
        return;
    }
    if (feedback) {
        quizText.text = feedback + "\n目前得分：" + score + " / " + questions.length;
        return;
    }
    quizText.text = ""  + "" + "\n" + questions[questionIndex].prompt + "\n\n" + (awaitingNeutral ? "先回正再答題" : "將頭傾向選項並保持 2 秒");
}

function submitAnswer(direction) {
    if (direction === questions[questionIndex].correct) {
        score++;
        feedback = "答對了！";
    } else {
        feedback = "答錯了，再接再厲！";
    }
    feedbackTimer = 0.8;
    awaitingNeutral = true;
    holdTimer = 0;
    lastDirection = -1;
    updateDisplay();
}

script.createEvent("UpdateEvent").bind(function(eventData) {
    var dt = eventData.getDeltaTime();
    if (finished || !headBinding || !headBinding.getTransform()) { return; }
    var currentRotation = headBinding.getTransform().getWorldRotation();
    if (!baseRotation) { baseRotation = currentRotation; updateDisplay(); return; }
    var relativeRotation = baseRotation.invert().multiply(currentRotation);
    var euler = relativeRotation.toEulerAngles();
    var roll = euler.z * 180 / Math.PI;
    if (roll > 180) { roll -= 360; }
    if (roll < -180) { roll += 360; }
    var direction = roll >= tiltThreshold ? 0 : (roll <= -tiltThreshold ? 1 : -1);
    if (feedback) {
        feedbackTimer -= dt;
        if (feedbackTimer <= 0) {
            feedback = "";
            questionIndex++;
            if (questionIndex >= questions.length) { finished = true; }
            updateDisplay();
        }
        return;
    }
    if (awaitingNeutral) {
        if (direction === -1) {
            neutralTimer += dt;
            if (neutralTimer >= 0.22) { awaitingNeutral = false; neutralTimer = 0; updateDisplay(); }
        } else { neutralTimer = 0; }
        return;
    }
    if (direction === -1) { holdTimer = 0; lastDirection = -1; return; }
    if (direction !== lastDirection) { lastDirection = direction; holdTimer = 0; }
    holdTimer += dt;
    if (holdTimer >= holdRequired) { submitAnswer(direction); }
});

updateDisplay();